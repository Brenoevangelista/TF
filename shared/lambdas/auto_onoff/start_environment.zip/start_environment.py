import boto3
import logging
import json

#Lists
service_list = []
cluster_list = []

logger = logging.getLogger()
logger.setLevel(logging.INFO) 


#Starting RDS Instances
def start_rds_instances(key, value):
    rds = boto3.client('rds')

    dbs = rds.describe_db_instances()
    db_instances = list(filter(lambda a: any(list(filter(lambda f: all([f.get('Key')==key,f.get('Value')==value]), a.get('TagList')))), dbs.get('DBInstances')))
    db_instances_on = [db.get('DBInstanceIdentifier') for db in db_instances]

    for db_instance_on in db_instances_on:
        try:
            rds.start_db_instance(
                DBInstanceIdentifier=db_instance_on
            )
        except:
            pass


#Starting ECS Services
def start_ecs_services():
    ecs_client = boto3.client('ecs')
    ecs_paginator = ecs_client.get_paginator('list_clusters')
    ecs_response_iterator = ecs_paginator.paginate()

    print('Getting ECS Clusters...')
    for ecs_clusters in ecs_response_iterator:
        clusters = ecs_clusters['clusterArns']
        cluster_list.append(clusters)
    clusters=clusters
    ecs_cluster_filtering = ecs_client.describe_clusters(clusters=clusters, include=['TAGS'])

    print('Filtering ECS Clusters using the auto_onoff tag...')
    for cluster_services in ecs_cluster_filtering['clusters']:
            tags = cluster_services.get('tags')
            
            for value in tags:
                if 'auto_onoff' in value['key'] and value['value'] == 'true':
                    target_clusters = cluster_services.get('clusterName')
                    print(f'{target_clusters} will be started...')
                else:
                    continue
                target_services = ecs_client.list_services(cluster=target_clusters)
                target_services = target_services.get('serviceArns')

                for service in target_services:
                    get_naming_position = service.find('/')
                    service_name = service[get_naming_position+1:]
                    get_naming_position = service_name.find('/')
                    service_name = service_name[get_naming_position+1:]
                    
                    try:
                        print(f'Starting service: {service_name}...')
                        ecs_client.update_service(
                            cluster=target_clusters,
                            service=service,
                            desiredCount=0,
                            forceNewDeployment=True) 
                    except:
                        pass
print("Services were sucessfully started")

def lambda_handler(event, context):
    start_rds_instances('auto_onoff', 'true')
    start_ecs_services()