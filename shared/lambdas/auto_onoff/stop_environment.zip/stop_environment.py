#lambda function to stop every resource in a test environment

import boto3
import logging
import json

#Lists
service_list = []
cluster_list = []

logger = logging.getLogger()
logger.setLevel(logging.INFO) 


#Stopping RDS Instances
def stop_rds_instances(key, value):
    rds = boto3.client('rds')

    dbs = rds.describe_db_instances()
    db_instances = list(filter(lambda a: any(list(filter(lambda f: all([f.get('Key')==key,f.get('Value')==value]), a.get('TagList')))), dbs.get('DBInstances')))
    db_instances_off = [db.get('DBInstanceIdentifier') for db in db_instances]

    for db_instance_off in db_instances_off:
        try:
            rds.stop_db_instance(
                DBInstanceIdentifier=db_instance_off
            )
        except:
            pass


#Stopping ECS Services
def stop_ecs_services():
    ecs_client = boto3.client('ecs')
    ecs_paginator = ecs_client.get_paginator('list_clusters')
    ecs_response_iterator = ecs_paginator.paginate()

    print('Getting ECS Clusters...')
    for ecs_clusters in ecs_response_iterator:
        clusters = ecs_clusters['clusterArns']
        cluster_list.append(clusters)
    clusters=clusters
    ecs_cluster_filtering = ecs_client.describe_clusters(clusters=clusters, include=['TAGS'])

    print('Filtering ECS Clusters using the auto-onoff tag...')
    for cluster_services in ecs_cluster_filtering['clusters']:
            tags = cluster_services.get('tags')
            
            for value in tags:
                if 'auto-onoff' in value['key']:
                    target_clusters = cluster_services.get('clusterName')
                    print(f'{target_clusters} will be stopped...')
                else:
                    continue
                target_services = ecs_client.list_services(cluster=target_clusters)
                target_services = target_services.get('serviceArns')

            for service in target_services:
                get_naming_position = service.find('/')
                service_name = service[get_naming_position+1:]
                get_naming_position = service_name.find('/')
                service_name = service_name[get_naming_position+1:]
                
                try:
                    print(f'Stopping service: {service_name}...')
                    ecs_client.update_service(
                        cluster=target_clusters,
                        service=service,
                        desiredCount=0,
                        forceNewDeployment=True) 
                except:
                        pass
print("Services were sucessfully stopped")

def lambda_handler(event, context):
    stop_rds_instances('auto-onoff', 'true')
    stop_ecs_services()