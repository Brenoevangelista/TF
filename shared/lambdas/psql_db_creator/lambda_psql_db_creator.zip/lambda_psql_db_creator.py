import os
import psycopg2
import boto3

app_name                 = os.environ['APP_NAME']
desired_db_name          = os.environ['DESIRED_DB_NAME']
target_psql_db_host      = os.environ['TARGET_PSQL_DB_HOST']
environment              = os.environ['ENVIRONMENT']

def lambda_handler(event, context):
    try:
        ssm = boto3.client('ssm')
        app_name_db_name      = ""
        app_name_db_user_name = ""
        app_name_db_password  = "" 
        
        if "shared" in target_psql_db_host:
            shared_db_name       = ssm.get_parameter(Name=f'/sld/{environment}/shared_psql/db_name', WithDecryption=True)['Parameter']['Value']
            shared_db_password   = ssm.get_parameter(Name=f'/sld/{environment}/shared_psql/db_password', WithDecryption=True)['Parameter']['Value']
            shared_db_user_name  = ssm.get_parameter(Name=f'/sld/{environment}/shared_psql/db_user', WithDecryption=True)['Parameter']['Value']
            app_name_db_user_name= ssm.get_parameter(Name=f'/sld/{environment}/{app_name}/db_user', WithDecryption=True)['Parameter']['Value']
            app_name_db_password = ssm.get_parameter(Name=f'/sld/{environment}/{app_name}/db_password', WithDecryption=True)['Parameter']['Value']
        else:
            app_name_db_name     = ssm.get_parameter(Name=f'/sld/{environment}/{app_name}/db_name', WithDecryption=True)['Parameter']['Value']
            app_name_db_password = ssm.get_parameter(Name=f'/sld/{environment}/{app_name}/db_password', WithDecryption=True)['Parameter']['Value']
            app_name_db_user_name= ssm.get_parameter(Name=f'/sld/{environment}/{app_name}/db_user', WithDecryption=True)['Parameter']['Value']
        
        # Connect to PostgreSQL database
        conn = psycopg2.connect(
            host=target_psql_db_host,
            user=shared_db_user_name if shared_db_user_name else app_name_db_user_name,
            password=shared_db_password if shared_db_password else app_name_db_password,
            dbname=shared_db_name if "shared" in target_psql_db_host else app_name_db_name,
            port=5432
        ) 
        
        # Create new database and user
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE {desired_db_name};")
        cursor.execute(f"CREATE USER {app_name_db_user_name} WITH PASSWORD '{app_name_db_password}';") 
        cursor.execute(f"GRANT ALL PRIVILEGES ON DATABASE {desired_db_name} TO {app_name_db_user_name};")
        cursor.execute(f"ALTER USER {app_name_db_user_name} CREATEDB;")      
        conn.commit() 
        
        # Close database connection
        cursor.close()
        conn.close()
        
        return {
            'statusCode': 200,
            'body': f"Database and user created successfully for {app_name}!"
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f"Error: {str(e)}"
        }